The Agent Doctrine: Tools
Version 1.0, November 2026
Michael Elkær Meisner
elkaermeisner.com/doctrine

Seven tools that put The Agent Doctrine to work. Each is a template with an example from the book.

Start
  First 90 Days (Excel)              Chapter 13, Appendix A.1
  Agent Register (Excel)             Chapters 8 and 9, Appendix A.2 to A.5

Measure
  Ladder Assessment (Excel)          Chapter 14, Appendix A.11 and C
  Cost Measurement (Excel)           Chapter 13, Appendix A.16

Run
  Incident and Stop Log (Excel)      Chapter 11, Appendix A.9
  Supplier Terms Checklist (Word)    Chapter 12, Appendix A.10
  The Board's Quarterly Page (Word)  Chapter 4, Appendix A.13

See LICENCE.txt for the terms of use.
